import {createStore} from "redux";


const initialState = {
    todoLists: [
        // {"id": 0, "title": 1,  tasks: [{"id":0,"title":"a2","isDone":false,"priority":"low"}]},
        // {"id": 1, "title": 2,  tasks: [{"id":1,"title":"wreewr","isDone":false,"priority":"low"},
        //         {"id":3,"title":"wree","isDone":false,"priority":"low"}]}
    ]
};


const reducer = (state = initialState, action) => {
    switch (action.type) {
        case "ADD-TODOLIST":
            debugger
            return {
                ...state,
                todoLists: [...state.todoLists, action.newTodoList]
            }
        case "ADD-TASK":
            return {
                ...state,
                todoLists: state.todoLists.map(tl => {
                    if (tl.id === action.todoListId) {
                        return {...tl, tasks: [...tl.tasks, action.newTask]}
                    } else {
                        return tl
                    }
                })
            }
        case  "CHANGE-TASK":
            return {
                ...state,
                todoLists: state.todoLists.map(tl => {
                    if (tl.id === action.todoListId) {
                        return {
                            ...tl, tasks: tl.tasks.map(task => {
                                if (task.id !== action.taskId) {
                                    return task;
                                } else {
                                    return {...task, ...action.obj}
                                }
                            })
                        }
                    } else {
                        return tl
                    }
                })
            }
        case "DELETE-TODOLIST":
            return {
                ...state,
                todoLists: state.todoLists.filter(tl => (tl.id !== action.todoListId)
                )
            }
        case "DELETE-TODOLISTTASK":
            debugger
            return {
                ...state,
                todoLists: state.todoLists.map(tl => {
                    if (tl.id === action.todoListId) {
                        return {
                            ...tl, tasks: tl.tasks.filter(task => (task.id !== action.taskId)
                            )
                        }
                    } else {
                        return tl
                    }
                })
            }
    }
    return state;
};


const store = createStore(reducer);
export default store;

